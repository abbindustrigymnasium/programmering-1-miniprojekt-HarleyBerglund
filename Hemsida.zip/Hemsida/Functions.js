function capitalizeFirstLetter(string) {                                    //Takes a sting with lowercase and turns the first letter into uppercase
    return string.charAt(0).toUpperCase() + string.slice(1);
}

